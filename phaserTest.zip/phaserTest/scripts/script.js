let config = {
  type: Phaser.AUTO,
  width: 800,
  height: 600,
  backgroundColor: 0x444444,
  physics: {
    default: "arcade",
    debug: true
  },
  scene: GameScene
};

let game = new Phaser.Game(config);