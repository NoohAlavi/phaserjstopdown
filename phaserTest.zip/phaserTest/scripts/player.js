class Player extends Phaser.Physics.Arcade.Sprite {
  
  constructor (scene, x, y, key, input, pointer) {
    super(scene, x, y, key);
    
    this.input = input;
    this.pointer = pointer;
    
    this.movementSpeed = 200;
    
    this.scene.add.existing(this);
    this.scene.physics.add.existing(this);
  }
  
  update() {
    
    //reset vel
    this.setVelocityX(0);
    this.setVelocityY(0);
    
    //input
    if (this.input.D.isDown) {
      this.setVelocityX(this.movementSpeed);
    } if (this.input.A.isDown) {
      this.setVelocityX(-this.movementSpeed);
    } if (this.input.W.isDown) {
      this.setVelocityY(-this.movementSpeed);
    } if (this.input.S.isDown) {
      this.setVelocityY(this.movementSpeed);
    }
    
    //rotate to mouse
    this.rotation = Phaser.Math.Angle.Between(this.x, this.y, this.pointer.worldX, this.pointer.worldY);
  }
  
}