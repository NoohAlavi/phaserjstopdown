class GameScene
{
  
  preload() {
    this.load.image('player', 'assets/player.png');
  }
  
  create() {
    let cursors = this.input.keyboard.createCursorKeys();
    let pointer = this.input.activePointer;
    
    let input = this.input.keyboard.addKeys('W, A, S, D');
    
    //create player
    this.player = new Player(this, 400, 300, 'player', input, pointer);
    //create cursor keys
  }
  
  update() {
    this.player.update();
  }
  
  draw() {
    
  }
}